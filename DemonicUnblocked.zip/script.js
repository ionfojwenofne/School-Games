console.log("i am dad");
console.log("i love dad :)")
